# Othello Coach (Cordova Android)

A self-contained Othello/Reversi game designed for Android portrait orientation.

## Features
- Human vs computer game with three AI strengths.
- Practice mode with guided goals and explanations.
- Coach feedback explains why a move is strong or weak.
- Legal move hints, pass handling, score, restart and undo.
- Responsive touch-first board; no remote services or paid APIs.

## Build on a computer
Install Node.js (LTS), Java JDK 17, and Android Studio with Android SDK tools.

```bash
npm install
npx cordova platform add android
npx cordova build android
```

To install on a connected Android device with USB debugging enabled:

```bash
npx cordova run android
```

The generated APK is normally under:
`platforms/android/app/build/outputs/apk/debug/app-debug.apk`

## Open directly on Android for a quick browser test
Open `www/index.html` in a modern mobile browser. Cordova packaging is needed for a native APK.

## How to play
Place a disc so that one or more opponent discs are trapped in a straight line between your new disc and another of your discs. Trapped discs flip to your colour. If you have no legal move, your turn is passed. The game ends when neither player can move or the board is full.

## Practice mode
Practice gives you a sequence of strategic missions:
1. Learn to capture discs.
2. Prefer corners because they cannot be flipped.
3. Avoid dangerous squares next to empty corners.
4. Learn to preserve mobility and reduce the opponent's options.
5. Review a suggested move and why it is preferred.

The coach evaluates the current board and gives contextual advice. Practice missions are guided scenarios, not a scripted tutorial that forces one exact move.


## Free cloud APK build with GitHub Actions

This project includes `.github/workflows/android.yml`.

1. Create a **private** repository on GitHub named `othello-coach`.
2. Upload the contents of this project to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow**. A push to `main` also starts a build.
5. When the run finishes, open the run and download the `othello-coach-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone.

GitHub Free currently includes a monthly allowance of Actions minutes for private repositories; public repositories use standard GitHub-hosted runners at no charge. Usage limits and policy can change, so check GitHub's current Actions billing page.

This workflow creates a **debug APK** for personal testing. It is not a signed Play Store release.
