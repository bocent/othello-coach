(() => {
  "use strict";
  const SIZE=8, EMPTY=0, BLACK=1, WHITE=2;
  const DIRS=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
  const $=id=>document.getElementById(id);
  let board, turn=BLACK, history=[], lastMove=null, busy=false, mode="game", mission=0, missionDone=false;
  const missions=[
    {title:"Learn to capture",text:"A legal move traps at least one opposing disc between your new disc and another disc of yours. Watch how the line flips after your move.",tip:"Do not choose a square just because it flips many discs. First make sure it does not give away a corner."},
    {title:"Corners are forever",text:"A corner disc can never be outflanked, so it can never flip. When a corner is available, it is usually your highest-priority move.",tip:"Look at all four corners before every move. Taking one creates a stable anchor for future lines."},
    {title:"Respect the danger squares",text:"The diagonal square beside an empty corner is called an X-square. Playing there can let your opponent take the corner next.",tip:"Avoid the diagonal neighbour of an empty corner unless you can prove the corner cannot be taken."},
    {title:"Think about mobility",text:"Mobility means the number of legal moves available. More choices give you control; fewer choices can force your opponent into a bad move.",tip:"Early in the game, prefer moves that keep your options open and limit the opponent's options."},
    {title:"Win the endgame",text:"Near the end, count empty squares and plan several moves ahead. A move that flips many discs now may still lose the final count.",tip:"In the late game, calculate the final disc count and look for forced passes."}
  ];
  function freshBoard(){const b=Array.from({length:8},()=>Array(8).fill(EMPTY));b[3][3]=WHITE;b[3][4]=BLACK;b[4][3]=BLACK;b[4][4]=WHITE;return b}
  function inside(r,c){return r>=0&&r<8&&c>=0&&c<8}
  function flipsFor(b,r,c,color){if(!inside(r,c)||b[r][c]!==EMPTY)return [];let out=[];for(const [dr,dc] of DIRS){let rr=r+dr,cc=c+dc,line=[];while(inside(rr,cc)&&b[rr][cc]===3-color){line.push([rr,cc]);rr+=dr;cc+=dc}if(line.length&&inside(rr,cc)&&b[rr][cc]===color)out.push(...line)}return out}
  function legalMoves(b,color){const m=[];for(let r=0;r<8;r++)for(let c=0;c<8;c++){const f=flipsFor(b,r,c,color);if(f.length)m.push({r,c,flips:f})}return m}
  function count(b){let black=0,white=0;for(const row of b)for(const v of row){if(v===BLACK)black++;if(v===WHITE)white++}return {black,white}}
  function copy(b){return b.map(row=>row.slice())}
  function apply(b,m,color){const n=copy(b);n[m.r][m.c]=color;for(const [r,c] of m.flips)n[r][c]=color;return n}
  function isCorner(r,c){return (r===0||r===7)&&(c===0||c===7)}
  function emptyCornerRisk(r,c,b){return [[0,0,0,1,1,0,1,1],[0,7,0,6,1,6,1,7],[7,0,6,0,6,1,7,1],[7,7,6,7,6,6,7,6]].some(([cr,cc,ar,ac,br,bc])=>false)}
  function strategicRisk(r,c,b){
    const pairs=[{corner:[0,0],x:[1,1],cs:[[0,1],[1,0]]},{corner:[0,7],x:[1,6],cs:[[0,6],[1,7]]},{corner:[7,0],x:[6,1],cs:[[6,0],[7,1]]},{corner:[7,7],x:[6,6],cs:[[6,7],[7,6]]}];
    for(const p of pairs){if(b[p.corner[0]][p.corner[1]]===EMPTY){if(r===p.x[0]&&c===p.x[1])return 3;if(p.cs.some(([a,d])=>a===r&&d===c))return 1.5}}
    return 0;
  }
  function evaluate(b,color){const opp=3-color, weights=[[120,-25,20,5,5,20,-25,120],[-25,-45,-5,-5,-5,-5,-45,-25],[20,-5,15,3,3,15,-5,20],[5,-5,3,3,3,3,-5,5],[5,-5,3,3,3,3,-5,5],[20,-5,15,3,3,15,-5,20],[-25,-45,-5,-5,-5,-5,-45,-25],[120,-25,20,5,5,20,-25,120]];
    let pos=0;for(let r=0;r<8;r++)for(let c=0;c<8;c++)if(b[r][c]===color)pos+=weights[r][c];else if(b[r][c]===opp)pos-=weights[r][c];
    const mob=legalMoves(b,color).length-legalMoves(b,opp).length;const n=count(b),disc=(n[color===BLACK?"black":"white"]-n[opp===BLACK?"black":"white"]);
    return pos+mob*5+disc*(n.black+n.white>48?3:0);
  }
  function minimax(b,color,depth,alpha,beta,maximizing){
    const moves=legalMoves(b,color),opp=3-color;
    if(depth===0||(!moves.length&&!legalMoves(b,opp).length)){const n=count(b);if(!moves.length&&!legalMoves(b,opp).length)return (n[color===BLACK?"black":"white"]-n[opp===BLACK?"black":"white"])*10000;return evaluate(b,color)}
    if(!moves.length)return -minimax(b,opp,depth-1,-beta,-alpha,false);
    let best=-Infinity;
    for(const m of moves){const v=-minimax(apply(b,m,color),opp,depth-1,-beta,-alpha,false);best=Math.max(best,v);alpha=Math.max(alpha,v);if(alpha>=beta)break}
    return best;
  }
  function chooseAI(){const moves=legalMoves(board,WHITE);if(!moves.length)return null;const level=$("difficulty").value;const depth=level==="easy"?1:level==="medium"?3:5;if(level==="easy")return moves[Math.floor(Math.random()*moves.length)];
    let best=null,bestScore=-Infinity;for(const m of moves){const next=apply(board,m,WHITE);let score=-minimax(next,BLACK,depth-1,-Infinity,Infinity,false);score+=Math.random()*0.01;if(score>bestScore){bestScore=score;best=m}}return best}
  function render(){const b=$("board");b.innerHTML="";const humanMoves=turn===BLACK&&!busy?legalMoves(board,BLACK):[];const legal=new Set(humanMoves.map(m=>m.r+","+m.c));
    for(let r=0;r<8;r++)for(let c=0;c<8;c++){const cell=document.createElement("button");cell.className="cell";cell.setAttribute("role","gridcell");cell.setAttribute("aria-label",`Row ${r+1}, column ${c+1}${board[r][c]?" occupied":""}`);if(lastMove&&lastMove.r===r&&lastMove.c===c)cell.classList.add("last");if(legal.has(r+","+c))cell.classList.add("legal");if(board[r][c]){const p=document.createElement("span");p.className="piece "+(board[r][c]===BLACK?"black":"white");cell.appendChild(p)}cell.disabled=!legal.has(r+","+c);cell.addEventListener("click",()=>humanMove(r,c));b.appendChild(cell)}
    const n=count(board);$("blackScore").textContent=n.black;$("whiteScore").textContent=n.white;
    $("turnLabel").textContent=busy?"COMPUTER THINKING":turn===BLACK?"YOUR TURN":"COMPUTER TURN";
    $("statusText").textContent=busy?"Choosing a move…":turn===BLACK?"Place a dark disc":"White is to move";
    $("humanScoreCard").classList.toggle("active",turn===BLACK&&!busy);$("aiScoreCard").classList.toggle("active",turn===WHITE||busy);
    $("legalLegend").textContent=humanMoves.length?`${humanMoves.length} legal move${humanMoves.length===1?"":"s"}`:"No legal move";
  }
  function explainMove(m,color,before){const corner=isCorner(m.r,m.c),risk=strategicRisk(m.r,m.c,before),opp=3-color,after=apply(before,m,color),mob=legalMoves(after,opp).length;
    if(corner)return "Excellent! A corner is permanent: your opponent can never flip this disc. Build your position outward from it.";
    if(risk>=3)return "Careful: this is an X-square beside an empty corner. Your opponent may be able to take that corner next. Look for another legal move.";
    if(risk>0)return "This square is next to an empty corner. It can be risky because it may help your opponent claim the corner.";
    if(mob<=2)return "Strong restriction! After this move, your opponent has very few legal choices. Limiting mobility can control the game.";
    if(m.flips.length>=4)return "You flip several discs, but remember: having the most discs early is not the main goal. Keep corners and mobility in mind.";
    return "A legal, steady move. Before placing it, check whether it gives your opponent access to a corner and how many replies they will have.";
  }
  function setCoach(title,text,tag="STRATEGY INSIGHT"){ $("coachTitle").textContent=title;$("coachText").textContent=text;$("coachTag").textContent=tag;$("coachAction").hidden=true}
  function finishIfNeeded(){const a=legalMoves(board,turn),b=legalMoves(board,3-turn);if(!a.length&&!b.length){const n=count(board);setCoach(n.black>n.white?"You win!":n.black<n.white?"Computer wins":"It's a draw",`Final score: You ${n.black} — Computer ${n.white}. ${n.black>n.white?"Great strategy!":n.black<n.white?"Review the corner and mobility lessons, then try again.":"Well played."}`,"GAME OVER");$("turnLabel").textContent="GAME OVER";$("statusText").textContent="No legal moves remain";return true}return false}
  function passIfNeeded(){if(!legalMoves(board,turn).length){const who=turn===BLACK?"You have no legal move":"Computer has no legal move";turn=3-turn;setCoach("Turn passed",`${who}, so the turn passes. This is a normal part of Othello.`,"PASS");render();return true}return false}
  function humanMove(r,c){if(busy||turn!==BLACK)return;const m=legalMoves(board,BLACK).find(x=>x.r===r&&x.c===c);if(!m)return;history.push({board:copy(board),turn,lastMove});const before=copy(board);board=apply(board,m,BLACK);lastMove={r,c};setCoach("Your move",explainMove(m,BLACK,before));if(mode==="practice")checkMission(m,before);turn=WHITE;render();if(finishIfNeeded())return;if(passIfNeeded()){if(finishIfNeeded())return;if(turn===BLACK)return}window.setTimeout(computerTurn,380)}
  function computerTurn(){if(finishIfNeeded())return;if(!legalMoves(board,WHITE).length){turn=BLACK;setCoach("Computer passes","The computer has no legal move, so you get another turn.","PASS");render();return}busy=true;render();window.setTimeout(()=>{const m=chooseAI();busy=false;if(m){history.push({board:copy(board),turn,lastMove});const before=copy(board);board=apply(board,m,WHITE);lastMove={r:m.r,c:m.c};setCoach("Computer played",`The computer chose ${String.fromCharCode(65+m.c)}${m.r+1}. ${explainMove(m,WHITE,before)}`,"OPPONENT MOVE")}turn=BLACK;render();if(!finishIfNeeded())passIfNeeded();if(!finishIfNeeded()&&turn===WHITE)computerTurn()},220)}
  function checkMission(m,before){const ms=missions[mission];let done=false;if(mission===0)done=m.flips.length>0;if(mission===1)done=isCorner(m.r,m.c);if(mission===2)done=strategicRisk(m.r,m.c,before)===0;if(mission===3)done=legalMoves(apply(before,m,BLACK),WHITE).length<=2;if(mission===4)done=true;
    if(done&&!missionDone){missionDone=true;$("coachTitle").textContent="Lesson progress";$("coachText").textContent="Nice work. "+ms.tip;$("coachTag").textContent="MISSION COMPLETE";$("coachAction").hidden=false;$("coachAction").textContent="You can continue to the next lesson below.";$("nextMission").textContent=mission===4?"Finish practice ✓":"Next lesson →"}}
  function showMission(){const m=missions[mission];$("missionCount").textContent=`MISSION ${mission+1} / ${missions.length}`;$("missionTitle").textContent=m.title;$("missionText").textContent=m.text;$("missionProgress").style.width=((mission+1)/missions.length*100)+"%";$("nextMission").textContent=mission===4?"Restart lessons ↻":"Next lesson →";missionDone=false;setCoach("Practice tip",m.tip,"GUIDED LEARNING")}
  function newGame(){board=freshBoard();turn=BLACK;history=[];lastMove=null;busy=false;render();if(mode==="practice")showMission();else setCoach("Coach tip","Corners are the strongest squares. Try to secure one when it is safe.");}
  function undo(){if(!history.length||busy)return;const prev=history.pop();board=prev.board;turn=prev.turn;lastMove=prev.lastMove;if(turn===WHITE&&history.length){const p=history.pop();board=p.board;turn=p.turn;lastMove=p.lastMove}render();setCoach("Move undone","Try a different plan. Look at corners, risky squares and your number of legal moves.");}
  function setMode(next){mode=next;document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.mode===mode));$("practicePanel").hidden=mode!=="practice";$("difficulty").disabled=mode==="practice";newGame()}
  $("restartBtn").addEventListener("click",newGame);$("undoBtn").addEventListener("click",undo);$("difficulty").addEventListener("change",()=>setCoach("Difficulty updated","The computer will use the selected search strength on its next turn."));document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>setMode(t.dataset.mode)));
  $("nextMission").addEventListener("click",()=>{mission=(mission+1)%missions.length;showMission()});
  $("helpBtn").addEventListener("click",()=>$("helpDialog").showModal());$("closeHelp").addEventListener("click",()=>$("helpDialog").close());$("gotIt").addEventListener("click",()=>$("helpDialog").close());
  newGame();
})();